#include "func.h"

#pragma warning(push)
#pragma warning (disable: 4100)

void cfunc3(unsigned char *pixels, long largura, long altura)
{
	return;
}

#pragma warning (pop)